<!-- <div align="center">
  
___ 
<p align="center">
<a href="HTML 5 url">
    <img alt="HTML 5" src="https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white" />
</a>
<a href="CSS 3 url" >
    <img alt="CSS 3" src="https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white" />
</a>
<a href="JavaScript url" >
    <img alt="JavaScript" src="https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E" />
</a>
<a href="Figma url" >
    <img alt="FIGMA" src="https://img.shields.io/badge/figma-%23F24E1E.svg?style=for-the-badge&logo=figma&logoColor=white" />
</a>
  <a href="MIT License url" >
     <img alt = "MIT LICENSE" src="https://img.shields.io/github/license/Ileriayo/markdown-badges?style=for-the-badge" />
    </a>
</p>
 -->


<!--   <br />
  <br />
  
  <img src="./readme-images/project-logo.png" />

  <br />

  <h1 align="center">Funel - Agency landing page</h1>


  Funel is a fully responsive digital agency landing page, <br />Responsive for all devices, built using HTML, CSS, and JavaScript.



</div>

<br />
<br />
 -->

